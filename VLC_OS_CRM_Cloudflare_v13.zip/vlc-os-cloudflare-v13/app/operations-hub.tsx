"use client";

import { useCallback, useEffect, useState } from "react";

type Role = "super_admin" | "sales_manager" | "sales" | "distributor";
type User = { id: string; name: string; role: Role; island: string | null };
type Client = { id: string; company_name: string; island: string };
type Delivery = { id: string; client_company?: string; island: string; status: string };
type RecordRow = Record<string, string | number | null>;

type Snapshot = {
  counts: { sponsors: number; vipMembers: number; couponsIssued: number; couponsRedeemed: number; distributionPoints: number; pendingPhotoAudits: number; openSalesTasks: number; availableWalletCents: number };
  sponsors: RecordRow[];
  vipMembers: RecordRow[];
  coupons: RecordRow[];
  commissionRules: RecordRow[];
  walletEntries: RecordRow[];
  payoutRequests: RecordRow[];
  inventory: RecordRow[];
  distributionPoints: RecordRow[];
  photoAudits: RecordRow[];
  salesCheckins: RecordRow[];
  salesTasks: RecordRow[];
  leaderboard: RecordRow[];
  bundles: RecordRow[];
  integrations: { email: boolean; whatsapp: boolean; payments: boolean; maps: boolean; photoAi: boolean };
};

const ISLANDS = ["Tenerife", "Gran Canaria", "Lanzarote", "Fuerteventura", "La Palma"];
const TABS = [
  ["overview", "Regia"],
  ["vip", "VIP & Sponsor"],
  ["finance", "Finanza"],
  ["inventory", "Spazi"],
  ["distribution", "Geo audit"],
  ["sales", "Sales Ops"],
] as const;

class RequestError extends Error {}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(path, init);
  const payload = await response.json() as { error?: { message?: string } } & T;
  if (!response.ok) throw new RequestError(payload.error?.message ?? "Operazione non riuscita.");
  return payload;
}

async function post(path: string, value: Record<string, unknown>) {
  return request(path, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(value) });
}

function euros(cents: number) {
  return new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR" }).format(cents / 100);
}

function when(value: unknown) {
  if (!value) return "—";
  return new Intl.DateTimeFormat("it-IT", { dateStyle: "short", timeStyle: "short" }).format(new Date(String(value)));
}

export function OperationsHub({ user, clients, users, deliveries, notify }: {
  user: User;
  clients: Client[];
  users: User[];
  deliveries: Delivery[];
  notify: (text: string, tone?: "ok" | "error") => void;
}) {
  const [data, setData] = useState<Snapshot | null>(null);
  const [tab, setTab] = useState<(typeof TABS)[number][0]>("overview");
  const [busy, setBusy] = useState(false);

  const refresh = useCallback(async () => {
    try { setData(await request<Snapshot>("/api/operations")); }
    catch (error) { notify(error instanceof Error ? error.message : "Moduli non disponibili.", "error"); }
  }, [notify]);

  useEffect(() => {
    const timer = window.setTimeout(() => { void refresh(); }, 0);
    return () => window.clearTimeout(timer);
  }, [refresh]);

  async function run(action: () => Promise<unknown>, success: string, form?: HTMLFormElement) {
    setBusy(true);
    try {
      await action();
      form?.reset();
      notify(success);
      await refresh();
    } catch (error) { notify(error instanceof Error ? error.message : "Operazione non riuscita.", "error"); }
    finally { setBusy(false); }
  }

  if (!data) return <section className="ops-page"><div className="module-loading"><span /><p>Caricamento moduli operativi…</p></div></section>;

  return <section className="ops-page operations-hub">
    <div className="hub-heading">
      <div><small>VLC OS · infrastruttura completa</small><h1>Regia operativa</h1><p>Sei moduli con dati reali, audit e separazione per isola.</p></div>
      <div className="hub-live"><span /> Dati sincronizzati</div>
    </div>
    <div className="hub-tabs" role="tablist" aria-label="Moduli VLC OS">
      {TABS.filter(([key]) => user.role !== "distributor" || ["overview", "distribution"].includes(key)).map(([key, label]) => <button key={key} className={tab === key ? "active" : ""} onClick={() => setTab(key)}>{label}</button>)}
    </div>

    {tab === "overview" && <Overview data={data} user={user} />}
    {tab === "vip" && user.role !== "distributor" && <VipPanel data={data} user={user} clients={clients} busy={busy} run={run} />}
    {tab === "finance" && user.role !== "distributor" && <FinancePanel data={data} user={user} busy={busy} run={run} />}
    {tab === "inventory" && user.role !== "distributor" && <InventoryPanel data={data} user={user} busy={busy} run={run} />}
    {tab === "distribution" && <GeoAuditPanel data={data} user={user} clients={clients} deliveries={deliveries} busy={busy} run={run} />}
    {tab === "sales" && user.role !== "distributor" && <SalesPanel data={data} user={user} users={users} clients={clients} busy={busy} run={run} />}
  </section>;
}

function Overview({ data, user }: { data: Snapshot; user: User }) {
  const integrations = [
    ["Email OTP", data.integrations.email, "Identità e ricevute"],
    ["WhatsApp", data.integrations.whatsapp, "Coupon e automazioni"],
    ["Stripe / SEPA", data.integrations.payments, "Incassi ricorrenti"],
    ["Mappe", data.integrations.maps, "Percorsi e mappe pubbliche"],
    ["AI fotografica", data.integrations.photoAi, "Controllo qualità immagini"],
  ] as const;
  return <>
    <div className="hub-metrics">
      <HubMetric label="Sponsor attivi" value={data.counts.sponsors} note="directory VIP" />
      <HubMetric label="Membri VIP" value={data.counts.vipMembers} note="consenso registrato" />
      <HubMetric label="Coupon usati" value={data.counts.couponsRedeemed} note={`${data.counts.couponsIssued} ancora validi`} />
      <HubMetric label="Punti distribuzione" value={data.counts.distributionPoints} note="sulle cinque isole" />
      <HubMetric label="Foto da verificare" value={data.counts.pendingPhotoAudits} note="audit geolocalizzato" />
      <HubMetric label="Task commerciali" value={data.counts.openSalesTasks} note="ancora aperti" />
    </div>
    <div className="hub-two">
      <div className="module-card">
        <header><div><span className="module-index">01</span><h2>Stato piattaforma</h2></div><small>Perimetro: {user.island ?? "tutte le isole"}</small></header>
        <div className="integration-list">{integrations.map(([label, connected, note]) => <div key={label}><span className={`integration-dot ${connected ? "connected" : "pending"}`} /><div><strong>{label}</strong><small>{note}</small></div><b>{connected ? "Collegato" : "Da collegare"}</b></div>)}</div>
      </div>
      <div className="module-card readiness-card">
        <header><div><span className="module-index">02</span><h2>Copertura moduli</h2></div></header>
        <div className="readiness-list">
          <Progress label="CRM, preventivi e contratti" value={90} />
          <Progress label="VIP Pass e sponsor" value={55} />
          <Progress label="Finanza e commissioni" value={45} />
          <Progress label="Distribuzione e foto" value={55} />
          <Progress label="Sales workflow" value={60} />
        </div>
        <p className="truth-note"><strong>Nota operativa:</strong> “Da collegare” significa che il modulo conserva già i dati, ma non comunica ancora con il servizio esterno.</p>
      </div>
    </div>
  </>;
}

function VipPanel({ data, user, clients, busy, run }: PanelProps & { clients: Client[] }) {
  const canManage = ["super_admin", "sales_manager"].includes(user.role);
  return <div className="hub-stack">
    <div className="hub-three">
      {canManage && <ActionCard index="01" title="Nuovo sponsor" text="Directory, vantaggio e PIN di redemption.">
        <form onSubmit={(event) => { event.preventDefault(); const form = event.currentTarget; const fd = new FormData(form); void run(() => post("/api/operations/sponsors", { name: fd.get("name"), island: fd.get("island"), category: fd.get("category"), offerTitle: fd.get("offerTitle"), discountText: fd.get("discountText"), merchantPin: fd.get("merchantPin"), clientId: fd.get("clientId") }), "Sponsor creato.", form); }}>
          <input name="name" placeholder="Nome sponsor" required />
          <select name="clientId"><option value="">Nessun cliente collegato</option>{clients.map((client) => <option key={client.id} value={client.id}>{client.company_name}</option>)}</select>
          <IslandSelect user={user} />
          <input name="category" placeholder="Categoria (es. Ristorante)" required />
          <input name="offerTitle" placeholder="Titolo offerta" required />
          <input name="discountText" placeholder="Vantaggio (es. -15%)" required />
          <input name="merchantPin" inputMode="numeric" pattern="[0-9]{4}" maxLength={4} placeholder="PIN negozio · 4 cifre" required />
          <button className="primary" disabled={busy}>Crea sponsor</button>
        </form>
      </ActionCard>}
      <ActionCard index="02" title="Nuovo membro VIP" text="Registrazione 1-click con consenso.">
        <form onSubmit={(event) => { event.preventDefault(); const form = event.currentTarget; const fd = new FormData(form); void run(() => post("/api/operations/vip-members", { name: fd.get("name"), phone: fd.get("phone"), island: fd.get("island"), consent: fd.get("consent") === "on" }), "Membro VIP registrato.", form); }}>
          <input name="name" placeholder="Nome e cognome" required />
          <input name="phone" placeholder="WhatsApp +34…" required />
          <IslandSelect user={user} />
          <label className="check-line"><input name="consent" type="checkbox" required /> Consenso contatto e regolamento</label>
          <button className="primary" disabled={busy}>Registra</button>
        </form>
      </ActionCard>
      <ActionCard index="03" title="Emetti coupon" text="Codice unico, tracciato e valido 30 giorni.">
        <form onSubmit={(event) => { event.preventDefault(); const form = event.currentTarget; const fd = new FormData(form); void run(() => post("/api/operations/coupons", { sponsorId: fd.get("sponsorId"), memberId: fd.get("memberId") }), "Coupon emesso.", form); }}>
          <select name="sponsorId" required><option value="">Seleziona sponsor</option>{data.sponsors.map((row) => <option key={String(row.id)} value={String(row.id)}>{row.name} · {row.island}</option>)}</select>
          <select name="memberId" required><option value="">Seleziona membro VIP</option>{data.vipMembers.map((row) => <option key={String(row.id)} value={String(row.id)}>{row.name} · {row.phone}</option>)}</select>
          <button className="primary" disabled={busy || !data.sponsors.length || !data.vipMembers.length}>Genera codice</button>
        </form>
      </ActionCard>
    </div>
    <div className="hub-two">
      <DataCard title="Sponsor e offerte" count={data.sponsors.length}>{data.sponsors.length ? data.sponsors.map((row) => <ListRow key={String(row.id)} title={String(row.name)} subtitle={`${row.category} · ${row.island}`} meta={String(row.discount_text)} status={String(row.status)} />) : <MiniEmpty text="Nessuno sponsor registrato." />}</DataCard>
      <DataCard title="Coupon e redemption" count={data.coupons.length}>{data.coupons.length ? data.coupons.map((row) => <ListRow key={String(row.id)} title={String(row.code)} subtitle={`${row.member_name} → ${row.sponsor_name}`} meta={row.redeemed_at ? `Usato ${when(row.redeemed_at)}` : `Scade ${when(row.expires_at)}`} status={String(row.status)} />) : <MiniEmpty text="Nessun coupon emesso." />}</DataCard>
    </div>
  </div>;
}

function FinancePanel({ data, user, busy, run }: PanelProps) {
  return <div className="hub-stack">
    <div className="hub-metrics compact"><HubMetric label="Disponibile" value={euros(data.counts.availableWalletCents)} note="wallet nel tuo perimetro" /><HubMetric label="Richieste" value={data.payoutRequests.filter((row) => row.status === "requested").length} note="da processare" /><HubMetric label="Regole attive" value={data.commissionRules.filter((row) => Number(row.active) === 1).length} note="commissioni" /></div>
    <div className="hub-two">
      <ActionCard index="01" title="Richiedi liquidazione" text="Il sistema blocca richieste oltre il saldo disponibile.">
        <form onSubmit={(event) => { event.preventDefault(); const form = event.currentTarget; const fd = new FormData(form); void run(() => post("/api/operations/payout-requests", { amountEuros: fd.get("amountEuros"), note: fd.get("note") }), "Richiesta inviata.", form); }}>
          <input name="amountEuros" type="number" min="10" step="0.01" placeholder="Importo €" required />
          <input name="note" placeholder="Nota facoltativa" />
          <button className="primary" disabled={busy}>Richiedi pagamento</button>
        </form>
      </ActionCard>
      {user.role === "super_admin" && <ActionCard index="02" title="Regola commissione" text="Percentuale globale o specifica per isola.">
        <form onSubmit={(event) => { event.preventDefault(); const form = event.currentTarget; const fd = new FormData(form); void run(() => post("/api/operations/commission-rules", { name: fd.get("name"), role: fd.get("role"), island: fd.get("island") || null, ratePercent: fd.get("ratePercent") }), "Regola commissione creata.", form); }}>
          <input name="name" placeholder="Nome regola" required />
          <select name="role" required><option value="sales">Sales</option><option value="sales_manager">Sales Manager</option><option value="distributor">Distributore</option></select>
          <select name="island"><option value="">Tutte le isole</option>{ISLANDS.map((island) => <option key={island}>{island}</option>)}</select>
          <input name="ratePercent" type="number" min="0" max="100" step="0.01" placeholder="Percentuale" required />
          <button className="primary" disabled={busy}>Salva regola</button>
        </form>
      </ActionCard>}
    </div>
    <div className="hub-two">
      <DataCard title="Movimenti wallet" count={data.walletEntries.length}>{data.walletEntries.length ? data.walletEntries.map((row) => <ListRow key={String(row.id)} title={String(row.description)} subtitle={`${row.user_name} · ${when(row.created_at)}`} meta={euros(Number(row.amount_cents))} status={String(row.status)} />) : <MiniEmpty text="I movimenti nasceranno da contratti e consegne approvate." />}</DataCard>
      <DataCard title="Richieste pagamento" count={data.payoutRequests.length}>{data.payoutRequests.length ? data.payoutRequests.map((row) => <div className="hub-list-row" key={String(row.id)}><div><strong>{row.user_name}</strong><small>{when(row.created_at)}</small></div><b>{euros(Number(row.amount_cents))}</b><span className={`module-status ${row.status}`}>{row.status}</span>{user.role === "super_admin" && row.status === "requested" && <div className="inline-actions"><button disabled={busy} onClick={() => void run(() => post("/api/operations/payout-requests/review", { id: row.id, status: "approved" }), "Pagamento approvato.")}>Approva</button><button disabled={busy} onClick={() => void run(() => post("/api/operations/payout-requests/review", { id: row.id, status: "rejected" }), "Pagamento rifiutato.")}>Rifiuta</button></div>}</div>) : <MiniEmpty text="Nessuna richiesta di pagamento." />}</DataCard>
    </div>
  </div>;
}

function InventoryPanel({ data, user, busy, run }: PanelProps) {
  const canManage = ["super_admin", "sales_manager"].includes(user.role);
  return <div className="hub-stack">
    {canManage && <ActionCard index="01" title="Nuovo spazio editoriale" text="Inventario per numero, isola e formato.">
      <form className="wide-form" onSubmit={(event) => { event.preventDefault(); const form = event.currentTarget; const fd = new FormData(form); void run(() => post("/api/operations/inventory", Object.fromEntries(fd)), "Spazio creato.", form); }}>
        <input name="issueLabel" placeholder="Numero (es. Settembre 2026)" required /><IslandSelect user={user} /><input name="slotCode" placeholder="Codice (es. P04-A)" required /><input name="slotName" placeholder="Nome spazio" required /><input name="widthMm" type="number" min="1" placeholder="Larghezza mm" required /><input name="heightMm" type="number" min="1" placeholder="Altezza mm" required /><button className="primary" disabled={busy}>Aggiungi spazio</button>
      </form>
    </ActionCard>}
    <div className="inventory-grid">{data.inventory.length ? data.inventory.map((row) => <article key={String(row.id)} className={`inventory-slot ${row.status}`}><header><span>{row.slot_code}</span><b>{row.status}</b></header><h3>{row.slot_name}</h3><p>{row.issue_label} · {row.island}</p><small>{row.width_mm} × {row.height_mm} mm</small>{canManage && <div className="inline-actions"><button disabled={busy} onClick={() => void run(() => post("/api/operations/inventory/status", { id: row.id, status: "held" }), "Spazio bloccato.")}>Blocca</button><button disabled={busy} onClick={() => void run(() => post("/api/operations/inventory/status", { id: row.id, status: "available" }), "Spazio liberato.")}>Libera</button></div>}</article>) : <MiniEmpty text="Crea il primo menabò commerciale." />}</div>
    <div className="bundle-strip"><div><small>Pacchetti preset</small><h2>Entry · Business · VIP</h2></div>{data.bundles.map((row) => <div key={String(row.id)}><strong>{row.name}</strong><span>{euros(Number(row.monthly_price_cents))}/mese</span><small>{row.description}</small></div>)}</div>
  </div>;
}

function GeoAuditPanel({ data, user, clients, deliveries, busy, run }: PanelProps & { clients: Client[]; deliveries: Delivery[] }) {
  const canManage = ["super_admin", "sales_manager"].includes(user.role);
  return <div className="hub-stack">
    <div className="hub-two">
      {canManage && <ActionCard index="01" title="Punto distribuzione" text="Coordinate, capacità, stock e visibilità pubblica.">
        <form onSubmit={(event) => { event.preventDefault(); const form = event.currentTarget; const fd = new FormData(form); void run(() => post("/api/operations/distribution-points", { ...Object.fromEntries(fd), publicVisible: fd.get("publicVisible") === "on" }), "Punto distribuzione creato.", form); }}>
          <input name="name" placeholder="Nome punto" required /><select name="clientId"><option value="">Nessun cliente collegato</option>{clients.map((client) => <option key={client.id} value={client.id}>{client.company_name}</option>)}</select><IslandSelect user={user} /><input name="address" placeholder="Indirizzo" required /><div className="field-pair"><input name="latitude" type="number" step="0.000001" placeholder="Latitudine" required /><input name="longitude" type="number" step="0.000001" placeholder="Longitudine" required /></div><div className="field-pair"><input name="capacity" type="number" min="0" placeholder="Capacità" required /><input name="stock" type="number" min="0" placeholder="Stock" required /></div><label className="check-line"><input type="checkbox" name="publicVisible" defaultChecked /> Visibile nella mappa pubblica</label><button className="primary" disabled={busy}>Salva punto</button>
        </form>
      </ActionCard>}
      <ActionCard index="02" title="Foto di consegna" text="Foto, posizione, hash e controllo geofence.">
        <form onSubmit={(event) => { event.preventDefault(); const form = event.currentTarget; void run(async () => { const location = await currentLocation(); const fd = new FormData(form); fd.set("latitude", String(location.latitude)); fd.set("longitude", String(location.longitude)); await request("/api/operations/photo-audits", { method: "POST", body: fd }); }, "Verifica fotografica inviata.", form); }}>
          <select name="deliveryId" required><option value="">Seleziona consegna</option>{deliveries.map((delivery) => <option key={delivery.id} value={delivery.id}>{delivery.client_company ?? delivery.id} · {delivery.island}</option>)}</select>
          <input name="photo" type="file" accept="image/jpeg,image/png,image/webp" capture="environment" required />
          <p className="form-microcopy">La posizione viene acquisita al momento dell’invio. La foto originale resta conservata con hash e watermark probatorio.</p>
          <button className="primary" disabled={busy || !deliveries.length}>Acquisisci posizione e invia</button>
        </form>
      </ActionCard>
    </div>
    <div className="hub-two">
      <DataCard title="Punti e stock" count={data.distributionPoints.length}>{data.distributionPoints.length ? data.distributionPoints.map((row) => <div className="hub-list-row" key={String(row.id)}><div><strong>{row.name}</strong><small>{row.address} · {row.island}</small></div><b className={Number(row.stock) <= Math.max(5, Number(row.capacity) * .15) ? "low-stock" : ""}>{row.stock}/{row.capacity}</b></div>) : <MiniEmpty text="Nessun punto geolocalizzato." />}</DataCard>
      <DataCard title="Audit fotografici" count={data.photoAudits.length}>{data.photoAudits.length ? data.photoAudits.map((row) => <div className="hub-list-row audit-row" key={String(row.id)}><div><strong>{row.distributor_name}</strong><small>{row.island} · {when(row.created_at)} · distanza {row.geofence_distance_m ?? "—"} m</small></div><b>Qualità {row.quality_score}%</b><span className={`module-status ${row.status}`}>{row.status}</span>{canManage && row.status === "pending" && <div className="inline-actions"><button disabled={busy} onClick={() => void run(() => post("/api/operations/photo-audits/review", { id: row.id, status: "approved" }), "Foto approvata.")}>Approva</button><button disabled={busy} onClick={() => void run(() => post("/api/operations/photo-audits/review", { id: row.id, status: "rejected" }), "Foto rifiutata.")}>Rifiuta</button></div>}</div>) : <MiniEmpty text="Nessuna foto da verificare." />}</DataCard>
    </div>
  </div>;
}

function SalesPanel({ data, user, users, clients, busy, run }: PanelProps & { users: User[]; clients: Client[] }) {
  const canManage = ["super_admin", "sales_manager"].includes(user.role);
  const salesUsers = users.filter((item) => ["sales", "sales_manager"].includes(item.role));
  return <div className="hub-stack">
    <div className="hub-two">
      {["sales", "sales_manager"].includes(user.role) && <ActionCard index="01" title="Check-in commerciale" text="Obiettivo ore 09:00, tolleranza fino alle 09:15.">
        <button className="primary location-button" disabled={busy} onClick={() => void run(async () => { const location = await currentLocation(); await post("/api/operations/sales-checkins", location); }, "Check-in registrato.")}>Registra posizione adesso</button>
        <p className="form-microcopy">Fuori dall’area dell’isola il check-in viene marcato per verifica.</p>
      </ActionCard>}
      {canManage && <ActionCard index="02" title="Assegna doppio task" text="Visita commerciale o controllo display.">
        <form onSubmit={(event) => { event.preventDefault(); const form = event.currentTarget; const fd = new FormData(form); void run(() => post("/api/operations/sales-tasks", Object.fromEntries(fd)), "Attività assegnata.", form); }}>
          <select name="userId" required><option value="">Commerciale</option>{salesUsers.map((item) => <option key={item.id} value={item.id}>{item.name} · {item.island}</option>)}</select><select name="clientId"><option value="">Nessun cliente collegato</option>{clients.map((client) => <option key={client.id} value={client.id}>{client.company_name}</option>)}</select><select name="kind"><option value="visit">Visita</option><option value="display_check">Controllo display</option></select><input name="title" placeholder="Obiettivo attività" required /><input name="scheduledFor" type="datetime-local" required /><button className="primary" disabled={busy}>Assegna</button>
        </form>
      </ActionCard>}
    </div>
    <div className="hub-two">
      <DataCard title="Attività aperte" count={data.salesTasks.filter((row) => row.status === "open").length}>{data.salesTasks.length ? data.salesTasks.map((row) => <div className="hub-list-row" key={String(row.id)}><div><strong>{row.title}</strong><small>{row.user_name} · {row.kind === "visit" ? "Visita" : "Display"} · {when(row.scheduled_for)}</small></div><span className={`module-status ${row.status}`}>{row.status}</span>{row.status === "open" && (row.user_id === user.id || canManage) && <button className="mini-complete" disabled={busy} onClick={() => void run(() => post("/api/operations/sales-tasks/complete", { id: row.id }), "Attività completata.")}>Completa</button>}</div>) : <MiniEmpty text="Nessuna attività commerciale." />}</DataCard>
      <DataCard title="Leaderboard" count={data.leaderboard.length}>{data.leaderboard.length ? data.leaderboard.map((row, index) => <div className="leader-row" key={String(row.user_id)}><span>{index + 1}</span><div><strong>{row.user_name}</strong><small>{row.island} · {row.won_count} chiusi</small></div><b>{euros(Number(row.won_value_cents))}</b></div>) : <MiniEmpty text="La classifica si alimenta con le opportunità chiuse." />}</DataCard>
    </div>
    <div className="bundle-strip"><div><small>Bundle live</small><h2>Offerta commerciale pronta</h2></div>{data.bundles.map((row) => <div key={String(row.id)}><strong>{row.name}</strong><span>{euros(Number(row.monthly_price_cents))}/mese</span><small>{row.description}</small></div>)}</div>
  </div>;
}

type PanelProps = { data: Snapshot; user: User; busy: boolean; run: (action: () => Promise<unknown>, success: string, form?: HTMLFormElement) => Promise<void> };

function ActionCard({ index, title, text, children }: { index: string; title: string; text: string; children: React.ReactNode }) {
  return <article className="module-card action-card"><header><div><span className="module-index">{index}</span><div><h2>{title}</h2><p>{text}</p></div></div></header><div className="action-body">{children}</div></article>;
}

function DataCard({ title, count, children }: { title: string; count: number; children: React.ReactNode }) {
  return <article className="module-card data-module"><header><div><h2>{title}</h2></div><small>{count} record</small></header><div className="hub-list">{children}</div></article>;
}

function ListRow({ title, subtitle, meta, status }: { title: string; subtitle: string; meta: string; status: string }) {
  return <div className="hub-list-row"><div><strong>{title}</strong><small>{subtitle}</small></div><b>{meta}</b><span className={`module-status ${status}`}>{status}</span></div>;
}

function HubMetric({ label, value, note }: { label: string; value: string | number; note: string }) {
  return <div className="hub-metric"><small>{label}</small><strong>{value}</strong><span>{note}</span></div>;
}

function Progress({ label, value }: { label: string; value: number }) {
  return <div><header><strong>{label}</strong><span>{value}%</span></header><div className="progress-track"><i style={{ width: `${value}%` }} /></div></div>;
}

function IslandSelect({ user }: { user: User }) {
  if (user.role !== "super_admin") return <input type="hidden" name="island" value={user.island ?? ""} />;
  return <select name="island" required><option value="">Seleziona isola</option>{ISLANDS.map((island) => <option key={island}>{island}</option>)}</select>;
}

function MiniEmpty({ text }: { text: string }) { return <div className="mini-empty"><span>◇</span><p>{text}</p></div>; }

async function currentLocation(): Promise<{ latitude: number; longitude: number }> {
  if (!("geolocation" in navigator)) throw new RequestError("Geolocalizzazione non disponibile sul dispositivo.");
  return new Promise((resolve, reject) => navigator.geolocation.getCurrentPosition(
    (position) => resolve({ latitude: position.coords.latitude, longitude: position.coords.longitude }),
    () => reject(new RequestError("Consenti l’accesso alla posizione per completare l’operazione.")),
    { enableHighAccuracy: true, timeout: 15_000, maximumAge: 0 },
  ));
}
